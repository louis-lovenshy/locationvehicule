<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Reservation</title>
</head>
<body>
<head>
    <title>LOCATION</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="res.css">
    <link rel="stylesheet" href="./css/animate.css" />
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet">
    <script src="./js/modernizr-3.5.0.min.js"></script>
</head>
<body>

<div class="row top-bar">
    <div class="col-sm-1"></div>
    <div class="col-sm-5 d-sm-block d-none" style="font-size: 13px">
        <i class="fa fa-comments"></i> CAR RENTAL &nbsp;
    </div>
    <div class="col-sm-2 col-6 text-center">
        <i class="fa fa-facebook-square"></i>
        <i class="fa fa-twitter-square"></i>
        <i class="fa fa-instagram"></i>
        <i class="fa fa-google-plus-square"></i>
        <i class="fa fa-linkedin"></i>
    </div>
</div>

<nav class="navbar navbar-expand-lg nav-bar navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="#">L-LOCATION <span class="navbar-brand2"> VOITURE</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto navi">
                <li class="nav-item">
                    <a class="nav-link nav-btn active" href="#">Acceuil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="liste.php">Liste Voiture</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="liste.php">Location</a>
                </li>
				<li class="nav-item">
                    <a class="nav-link nav-btn" href="chat/home.php">Chat</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="#">Loisir</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

   

<?php
	session_start();
	include './db.php';

	if (isset($_GET['r']) and isset($_GET['id'])) 
	{
		if ($_SESSION['userid']) 
		{ ?>

			<form method="POST">
			 <div class="reserv-box">
			  <h2>RESERVATION</h2>
			 <div class="inputs">
				<div class="user-box">
					<input type="date" name="date_debut" required=""  min="<?php echo date('Y-m-d'); ?>">
                    <label>Date debut reservation</label>
				</div><br><br>

				<div class="user-box">
					<input type="date" name="date_fin" required="" min="<?php echo date('Y-m-d'); ?>">
                    <label>Date fin reservation</label>
				</div><br><br>

				<div class="user-box">
					<input type="time" name="heure_depart" required="">
                    <label>Heure depart reservation</label>
				</div><br><br>

				<div class="user-box">
					<input type="time" name="heure_retour" required="">
                    <label>Heure retour reservation</label>
				</div><br><br>

				<div class="user-box">
					<select name="depart">
						<option>Delmas</option>
						<option>Petion-Ville</option>
						<option>Tabarre</option>
					</select>
                    <label>Lieu de depart</label>
				</div><br><br>

				<div class="user-box">
					<select name="retour">
						<option>Delmas</option>
						<option>Petion-Ville</option>
						<option>Tabarre</option>
					</select>
                    <label>Lieu de retour</label>
				</div><br><br>

                
			<!-- <input type="submit" name="submit" value="Envoyer"> -->
			</div>
                <div>
                    <a>
                        <button
                            type="submit" class="btn"> 
                                <span></span>
                                <!-- <span></span>
                                <span></span>
                                <span></span> -->
                            RESERVER
                        </button>
                    </a>
                </div>
			</div>
			</form>


			<?php
				if (isset($_POST['date_debut']) and isset($_POST['date_fin']) and isset($_POST['heure_depart']) and isset($_POST['heure_retour']) and isset($_POST['depart']) and isset($_POST['retour'])) 
				{
					$date_debut = mysqli_real_escape_string($db,htmlspecialchars($_POST['date_debut']));
					$date_fin = mysqli_real_escape_string($db,htmlspecialchars($_POST['date_fin']));
					$heure_depart = mysqli_real_escape_string($db,htmlspecialchars($_POST['heure_depart']));
					$heure_retour = mysqli_real_escape_string($db,htmlspecialchars($_POST['heure_retour']));
					$depart = mysqli_real_escape_string($db,htmlspecialchars($_POST['depart']));
					$retour = mysqli_real_escape_string($db,htmlspecialchars($_POST['retour']));

					$username = $_SESSION['username'];
					$id = $_GET['id'];

					$sql = "SELECT marque, modele, chaises, transmission FROM vehicules WHERE id = '".$id."' ";
					$reponse = mysqli_fetch_array(mysqli_query($db, $sql)); 
        			$marque = $reponse['marque'];
        			$modele = $reponse['modele'];
        			$chaises = $reponse['chaises'];
        			$transmission = $reponse['transmission'];

			 		$requete = "INSERT INTO reservation VALUES (null, '$username', '$id', '$date_debut', '$date_fin', '$heure_depart', '$heure_retour')";

			 		if (mysqli_query($db, $requete))
			 		{ ?>
			 			<script type="text/javascript">
			 				alert("Votre reservation a ete effectuee avec succes <?php echo $username; ?><?php echo " --Marque : " .$marque. " --Modele : " .$modele. " --Nbre de siege : " .$chaises. " --Transmission : " .$transmission. " --Date debut reservation : " .$date_debut. " --Heure depart : " .$heure_depart. " --Date fin reservation : " .$date_fin. " --Heure retour : ".$heure_retour; ?>");
			 				window.href.location = "liste.php";
			 			</script>
			 		<?php }
				}
		}

		else
	 	{
	 		header("Location: chat/index.php");
	 	}
	 }
?>

</body>
</html>
