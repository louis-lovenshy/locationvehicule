<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'location_vehicule';



$db = mysqli_connect($host,$username,$password,$dbname) or die ('Connexion impossible');
?>


<!--  -->

louislovenshy@protonmail.com
louislovenshy@protonmail.com17