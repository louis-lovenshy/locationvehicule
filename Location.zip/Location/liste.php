<?php
 include './db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>VOITURE</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/animate.css" />
    <link rel="stylesheet" href="liste.css" />
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet">
    <script src="./js/modernizr-3.5.0.min.js"></script>
</head>
<body>
       

<div class="row top-bar">
    <div class="col-sm-1"></div>
    <div class="col-sm-5 d-sm-block d-none" style="font-size: 13px">
        <i class="fa fa-envelope"></i> CAR RENTAL &nbsp;
    </div>
    <div class="col-sm-2 col-6 text-center">
        <i class="fa fa-facebook-square"></i>
        <i class="fa fa-twitter-square"></i>
        <i class="fa fa-instagram"></i>
        <i class="fa fa-google-plus-square"></i>
        <i class="fa fa-linkedin"></i>
    </div>
</div>

<nav class="navbar navbar-expand-lg nav-bar navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="#">L-LOCATION <span class="navbar-brand2"> VOITURE</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto navi">
                <li class="nav-item">
                    <a class="nav-link nav-btn active" href="index.php">Acceuil</a>
                <br>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="#">Liste Voiture</a>
                <br>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="chat/index.php">Chat</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="loisir.php">Loisir</a>
                <br>
            </ul>
        </div>
    </div>
</nav>

<div> 
    <br>

<?php
    session_start();
  $sql = "SELECT * FROM vehicules WHERE id = 1";
   $result = mysqli_query($db, $sql);
     if (mysqli_num_rows ($result) > 0){
      while($data = mysqli_fetch_array($result)) {
?>
         
         <div>
            <img class="ban d-none d-sm-block" src="img/v18.png"  >
            <div class="ban-text d-none d-sm-block animate-box" data-animate-effect="fadeInLeft">
               <h2>
                   Marque:
                    <?php  echo $marque = $data['marque'];?>
                </h2>
                <br>
                
               <h2>
                   Modele: 
                    <?php echo $modele = $data['modele']; ?>
                </h2>
                <br>
                
              <h2>
                  Prix: $
                    <?php echo $data['prix']; ?>
                </h2>   
                <br>
                
              <h2>
                  Chaises: 
                    <?php echo $chaises = $data['chaises']; ?>
                </h2>
                <br>
                
              <h2>
                  transmission: 
                    <?php echo $transmission = $data['transmission']; ?>
                </h2>
                <br>
               
                <div>
                    <a href="setReservation.php?r=1&id=1" class="btn btn-banner">Reserver</a>
                </div>   
            </div>
       </div>
<?php
 
 }
 
}
?>

<?php
  $sql = "SELECT * FROM vehicules WHERE id = 3";
   $result = mysqli_query($db, $sql);
     if (mysqli_num_rows ($result) > 0){
      while($data = mysqli_fetch_array($result)) {
?>   
        <div>
            <img class="ban2 d-none d-sm-block" src="img/v21.png" >
            <div class="ban2-text d-none d-sm-block animate-box" data-animate-effect="fadeInLeft">
                <h2>
                Marque: 
                    <?php  echo $marque = $data['marque'];?>
                </h2>
                <br>

                <h2>
                Modele: 
                    <?php echo $modele = $data['modele']; ?>
                 </h2>
                <br>
                
                <h2>
                Prix: $
                    <?php echo $data['prix']; ?>
                </h2>
                <br>
                
                <h2>
                Chaises: 
                    <?php echo $chaises = $data['chaises']; ?>
                </h2>
                <br>
                
                <h2>
                 transmission: 
                    <?php echo $transmission = $data['transmission']; ?>
                </h2>
                <br>  
               
                <div>
                   <a href="setReservation.php?r=1&id=3" class="btn btn-banner">Reserver</a>
                </div>  
            </div>
        </div>  
<?php
 
 }
 
}
?>


<?php
  $sql = "SELECT * FROM vehicules WHERE id = 4";
   $result = mysqli_query($db, $sql);
     if (mysqli_num_rows ($result) > 0){
      while($data = mysqli_fetch_array($result)) {
?>
        <div>
            <img class="ban3 d-none d-sm-block" src="img/v19.png" >
            <div class="ban3-text d-none d-sm-block animate-box" data-animate-effect="fadeInLeft">
               
                <h2>
                Marque: 
                    <?php  echo $marque = $data['marque'];?>
                </h2>
                <br>
               
               <h2>
                Modele: 
                    <?php echo $modele = $data['modele']; ?>
                    </h2>
                <br>
               
                
                <h2>
                Prix: $
                    <?php echo $data['prix']; ?>
                    </h2>
                <br> 
               
               <h2>
                Chaises: 
                    <?php echo $chaises = $data['chaises']; ?>
                    </h2>
                <br>
                
                <h2>
                transmission: 
                    <?php echo $transmission = $data['transmission']; ?>
                    </h2>
                <br>
                <a href="setReservation.php?r=1&id=4" class="btn btn-banner">Reserver</a>
        </div>
    </div>
<?php
 
 }
 
}
?>


<?php
  $sql = "SELECT * FROM vehicules WHERE id = 6";
   $result = mysqli_query($db, $sql);
     if (mysqli_num_rows ($result) > 0){
      while($data = mysqli_fetch_array($result)) {
?>
         
        <div ><br>
           
            <div> 
            <img class="ban4 d-none d-sm-block" src="img/v17.png" >
            <div class="ban4-text d-none d-sm-block animate-box" data-animate-effect="fadeInLeft">
               
                <h2>
                Marque: 
                    <?php  echo $marque = $data['marque'];?>
                    </h2>    
                <br>
               
                <h2>
                Modele: 
                    <?php echo $modele = $data['modele']; ?>
                    </h2>
                <br>
                
                <h2>
                Prix: $
                    <?php echo $data['prix']; ?>
                    </h2>
                <br>
               
                <h2>
                Chaises: 
                    <?php echo $chaises = $data['chaises']; ?>
                    </h2>
                <br>
                
                <h2>
                transmission: 
                    <?php echo $transmission = $data['transmission']; ?>
                    </h2>
                <br>

                <a href="setReservation.php?r=1&id=6" class="btn btn-banner">Reserver</a>
            </div>
        </div>
<?php
 
 }
 
}
?>

<?php
  $sql = "SELECT * FROM vehicules WHERE id = 8";
   $result = mysqli_query($db, $sql);
     if (mysqli_num_rows ($result) > 0){
      while($data = mysqli_fetch_array($result)) {
?>
         
        <div ><br>
            <div> 
            <img class="ban5 d-none d-sm-block" src="img/v27.png" >
            <div class="ban5-text d-none d-sm-block animate-box" data-animate-effect="fadeInLeft">
                
               <h2>
                Marque: 
                    <?php  echo $marque = $data['marque'];?>
                    </h2>
                <br>
               
                <h2>
                Modele: 
                    <?php echo $modele = $data['modele']; ?>
                    </h2>
                <br>
               
                <h2>
                Prix: $
                    <?php echo $data['prix']; ?>
                    </h2>
                <br>
                
                <h2>
                Chaises: 
                    <?php echo $chaises = $data['chaises']; ?>
                    </h2>
                <br>
                
                <h2>
                transmission: 
                    <?php echo $transmission = $data['transmission']; ?>
                    </h2>
                <br>

                <a href="setReservation.php?r=1&id=8" class="btn btn-banner">Reserver</a>
            </div>
        </div>
<?php
 
 }
 
}
?>

<?php
  $sql = "SELECT * FROM vehicules WHERE id = 9";
   $result = mysqli_query($db, $sql);
     if (mysqli_num_rows ($result) > 0){
      while($data = mysqli_fetch_array($result)) {
?>
         
        <div ><br>
            <div> 
            <img class="ban6 d-none d-sm-block" src="img/v29.png" >
            <div class="ban6-text d-none d-sm-block animate-box" data-animate-effect="fadeInLeft">
                
                <h2>
                Marque: 
                    <?php  echo $marque = $data['marque'];?>
                    </h2>
                <br>
                
                <h2>
                Modele: 
                    <?php echo $modele = $data['modele']; ?>
                    </h2>
                <br>
                
                <h2>
                Prix: $
                    <?php echo $data['prix']; ?>
                    </h2>
                <br>
                
                <h2>
                Chaises: 
                    <?php echo $chaises = $data['chaises']; ?>
                    </h2>
                <br>
                
                <h2>
                transmission: 
                    <?php echo $transmission = $data['transmission']; ?>
                    </h2>
                <br>

                <a href="setReservation.php?r=1&id=9" class="btn btn-banner">Reserver</a>
            </div>
        </div>
<?php
 
 }
 
}
?>

<?php
  $sql = "SELECT * FROM vehicules WHERE id = 10";
   $result = mysqli_query($db, $sql);
     if (mysqli_num_rows ($result) > 0){
      while($data = mysqli_fetch_array($result)) {
?>
         
        <div ><br>
            <div> 
            <img class="ban7 d-none d-sm-block" src="img/v28.png" >
            <div class="ban7-text d-none d-sm-block animate-box" data-animate-effect="fadeInLeft">

              <h2>
                Marque: 
                    <?php  echo $marque = $data['marque'];?>
                    </h2>
                <br>

                <h2>
                Modele: 
                    <?php echo $modele = $data['modele']; ?>
                    </h2>
                <br>
                
                <h2>
                Prix: $
                    <?php echo $data['prix']; ?>
                    </h2>
                <br>
                
                <h2>
                Chaises: 
                    <?php echo $chaises = $data['chaises']; ?>
                    </h2>
                <br>
                
                <h2>
                transmission: 
                    <?php echo $transmission = $data['transmission']; ?>
                    </h2>
                <br>

                <a href="setReservation.php?r=1&id=10"  class="btn btn-banner">Reserver</a>
            </div>
        </div>
<?php
 
 }
 
}
?>

<?php
  $sql = "SELECT * FROM vehicules WHERE id = 11";
   $result = mysqli_query($db, $sql);
     if (mysqli_num_rows ($result) > 0){
      while($data = mysqli_fetch_array($result)) {
?>
         
        <div ><br>
            <div> 
            <img class="ban8 d-none d-sm-block" src="img/v26.png" >
            <div class="ban8-text d-none d-sm-block animate-box" data-animate-effect="fadeInLeft">

                 <h2>
                Marque: 
                    <?php  echo $marque = $data['marque'];?>
                    </h2>
                <br>
                
                <h2>
                Modele: 
                    <?php echo $modele = $data['modele']; ?>
                    </h2>
                <br>
                
                <h2>
                Prix: $
                    <?php echo $data['prix']; ?>
                    </h2>
                <br>
                
                <h2>
                Chaises: 
                    <?php echo $chaises = $data['chaises']; ?>
                    </h2>
                <br>
                
                <h2>
                transmission: 
                    <?php echo $transmission = $data['transmission']; ?>
                    </h2>
                <br>

                <a href="setReservation.php?r=1&id=11" class="btn btn-banner">Reserver</a>
            </div>
        </div>
<?php
 
 }
 
}
?>

<?php
  $sql = "SELECT * FROM vehicules WHERE id = 12";
   $result = mysqli_query($db, $sql);
     if (mysqli_num_rows ($result) > 0){
      while($data = mysqli_fetch_array($result)) {
?>
         
        <div ><br> 
            <div> 
            <img class="ban9 d-none d-sm-block" src="img/v35.png" >
            <div class="ban9-text d-none d-sm-block animate-box" data-animate-effect="fadeInLeft">

                <h2>
                Marque: 
                    <?php  echo $marque = $data['marque'];?>
                    </h2>
                <br>
                
                <h2>
                Modele: 
                    <?php echo $modele = $data['modele']; ?>
                    </h2>
                <br>
                
                <h2>
                Prix: $
                    <?php echo $data['prix']; ?>
                    </h2>
                <br>
                
                <h2>
                Chaises: 
                    <?php echo $chaises = $data['chaises']; ?>
                    </h2>
                <br>
                
                 <h2>
                transmission: 
                    <?php echo $transmission = $data['transmission']; ?>
                    </h2>
                <br>

                <a href="setReservation.php?r=1&id=12" class="btn btn-banner">Reserver</a>
            </div>
        </div>
<?php
 
 }
 
}
?>

<?php
  $sql = "SELECT * FROM vehicules WHERE id = 13";
   $result = mysqli_query($db, $sql);
     if (mysqli_num_rows ($result) > 0){
      while($data = mysqli_fetch_array($result)) {
?>
         
        <div ><br>
            <div> 
            <img class="ban10 d-none d-sm-block" src="img/v37.png" >
            <div class="ban10-text d-none d-sm-block animate-box" data-animate-effect="fadeInLeft">

               <h2>
                Marque: 
                    <?php  echo $marque = $data['marque'];?>
                    </h2>
                <br>
                
                <h2>
                Modele: 
                    <?php echo $modele = $data['modele']; ?>
                    </h2>
                <br>
                
                <h2>
                Prix: $
                    <?php echo $data['prix']; ?>
                    </h2>
                <br>
                
                <h2>
                Chaises: 
                    <?php echo $chaises = $data['chaises']; ?>
                    </h2>
                <br>
                
                <h2>
                transmission: 
                    <?php echo $transmission = $data['transmission']; ?>
                    </h2>
                <br>

                <a href="setReservation.php?r=1&id=13" class="btn btn-banner">Reserver</a>
            </div>
        </div>
<?php
 
 }
 
}
?>

<?php
  $sql = "SELECT * FROM vehicules WHERE id = 14";
   $result = mysqli_query($db, $sql);
     if (mysqli_num_rows ($result) > 0){
      while($data = mysqli_fetch_array($result)) {
?>
         
        <div ><br>
            <div> 
            <img class="ban11 d-none d-sm-block" src="img/v36.png" >
            <div class="ban11-text d-none d-sm-block animate-box" data-animate-effect="fadeInLeft">

              <h2>
                Marque: 
                    <?php  echo $marque = $data['marque'];?>
                    </h2>
                <br>
               
               <h2>
                Modele: 
                    <?php echo $modele = $data['modele']; ?>
                    </h2>
                <br>
                
                <h2>
                Prix: $
                    <?php echo $data['prix']; ?>
                    </h2>
                <br>
                
                <h2>
                Chaises: 
                    <?php echo $chaises = $data['chaises']; ?>
                    </h2>
                <br>
                
                <h2>
                transmission: 
                    <?php echo $transmission = $data['transmission']; ?>
                    </h2>
                <br>

                <a href="setReservation.php?r=1&id=14" class="btn btn-banner">Reserver</a>
            </div>
        </div>
<?php
 
 }
 
}
?>

<?php
  $sql = "SELECT * FROM vehicules WHERE id = 15";
   $result = mysqli_query($db, $sql);
     if (mysqli_num_rows ($result) > 0){
      while($data = mysqli_fetch_array($result)) {
?>
         
        <div ><br>
            <div> 
            <img class="ban12 d-none d-sm-block" src="img/v33.png" >
            <div class="ban12-text d-none d-sm-block animate-box" data-animate-effect="fadeInLeft">

                 <h2>
                Marque: 
                    <?php  echo $marque = $data['marque'];?>
                    </h2>
                <br>
                
                <h2>
                Modele: 
                    <?php echo $modele = $data['modele']; ?>
                    </h2>
                <br>
                
                <h2>
                Prix: $
                    <?php echo $data['prix']; ?>
                    </h2>
                <br>
                
                <h2>
                Chaises: 
                    <?php echo $chaises = $data['chaises']; ?>
                    </h2>
                <br>
                
                <h2>
                transmission: 
                    <?php echo $transmission = $data['transmission']; ?>
                    </h2>
                <br>

                <a href="setReservation.php?r=1&id=15" class="btn btn-banner">Reserver</a>
            </div>
        </div>
<?php
 
 }
 
}
?>


<div class="dark">
    <div class="container animate-box" id="fh5co-footer">
        <div class="row">
            <div class="col-sm-4">
                <div><a class="nsavbar-brand" href="#">L-LOCATION <span class="navbar-brand2">VOITURE</span></a></div>
                <br>
                <div class="text-white">Chez Al-Location nous vous aidons a  vivre un sejour de reve avec votre voiture de reve, pour un prix abordable
                </div>
            </div>
            <div class="col-sm-4">
                <div class="icons">VISUALISER VOS PAGES</h2></div>
                <br>
                <table width="100%">
                    <tr>
                        <td><a class="text-white" href="#!">Home</a></td>
                        <td><a class="text-white" href="index.php">Acceuil</a></td>
                    </tr>
                    <tr>
                        <td><a class="text-white" href="liste.php">liste voiture</a></td>
                    </tr>
                    <tr>
                        <td><a class="text-white" href="liste.php">Location</a></td>
                    </tr>
                    <tr>
                        <td><a class="text-white" href="loisir.php">Loisir</a></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="darker">
    <div class="container" id="fh5co-legal">
        <div class="row">
            <div class="col-sm-8 text-white mtext-center">
                &copy; 2021 <a class="text-gr" href="#">L-LOCATION <span class="navbar-brand2">VOITURE</span></a>.
               
            </div>
            <div class="col-sm-4 text-white mtext-center">
                <table>
                    <tr>
                        <td><a class="text-white" href="#!">Legal</a></td>
                        <td><a class="text-white" href="#!">Sitemap</a></td>
                        <td><a class="text-white" href="#!">Privacy Policy</a></td>

                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>



<script src="./js/jquery.min.js"></script>
<script src="./js/bootstrap.min.js"></script>
<script src="./js/fontawesome.js"></script>
<script src="./js/jquery.waypoints.min.js"></script>
<script src="./js/animate.js"></script>

</body>
</html>