<!DOCTYPE html>
<html lang="en">
<head>
<title>VOITURE</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/animate.css" />
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet">
    <script src="./js/modernizr-3.5.0.min.js"></script>
</head>
<body>
<div class="row top-bar">
    <div class="col-sm-1"></div>
    <div class="col-sm-5 d-sm-block d-none" style="font-size: 13px">
        <i class="fa fa-comments"></i> CAR RENTAL &nbsp;
    </div>
    <div class="col-sm-2 col-6 text-center">
        <i class="fa fa-facebook-square"></i>
        <i class="fa fa-twitter-square"></i>
        <i class="fa fa-instagram"></i>
        <i class="fa fa-google-plus-square"></i>
        <i class="fa fa-linkedin"></i>
    </div>
    <div class="col-sm-3 col-6 login">
        <a href="#!" class="text-white">Login</a> &nbsp; 
        <a href="#!" class="text-white">Sign Up</a>&nbsp;
    </div>
</div>

<nav class="navbar navbar-expand-lg nav-bar navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="#">L-LOCATION <span class="navbar-brand2"> VOITURE</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto navi">
                <li class="nav-item">
                    <a class="nav-link nav-btn active" href="index.php">Acceuil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="liste.php">Liste Voiture</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="#">Location</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="chat/index.php">Chat</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="loisir.php">Loisir</a>
                </li>
                <li class="nav-item">
            </ul>
        </div>
    </div>
</nav>
     <div class="right"> 
        <br>
        <marquee behavior="" direction="">Hello ! Welcome to <b> Page Loisir</b> video of <b>Messi</b> </marquee>
      </div>
      
   
    <div class="corps">
       <div class="lo">
          <tr  class="aa">
            <td id="ss">
              <video src="Video/6 Messi goal vs Liverpool  3-0 Champions League _HD.mp4" poster="Download/400px-Russia_v_Argentina_-_Lionel_Messi.jpg" controls  ></video>
            </td>
          </tr>
          <tr class="aa">
            <td>
                <video src="Video/5 Lionel Messi ● Top 10 Free Kicks That Weren't Goals  !! __HD___HIGH.mp4" poster="Download/lionel-bc.jpg" Plays_HD controls></video>

            </td>
          </tr>
          <tr  class="aa">
            <td>
                <video src="Video/4 Lionel Messi - Wonder Goal vs Real Betis 1.mp4" poster="Download/45-452048_free-png-download-lionel-messi-png-images-background-1.png" controls ></video>

            </td>
          </tr>
          <tr  class="aa">
            <br>
            <td>
                <video src="Video/3 Lionel Messi ● Top 10 Cheeky Skills & Plays_HD.mp4" poster="Download//45-452048_free-png-download-lionel-messi-png-images-background-1.png" controls></video>

            </td>
          </tr>
          <tr  class="aa">
            <td>
                <video src="Video/2 Lionel Messi ● All 36 La Liga Goals in 2018-2019.mp4" poster="Download/lionel-bc.jpg" controls ></video>

            </td>
          </tr>
          <tr class="aa">
            <td>
                <video src="Video/1 Lionel Messi - Faded 1.mp4" poster="Download/400px-Russia_v_Argentina_-_Lionel_Messi.jpg" controls></video>

            </td>
          </tr>   
          <tr  class="aa">
            <br>
            <td>
                <video src="Video/6 Messi goal vs Liverpool  3-0 Champions League _HD.mp4" poster="AngeloPiza.png" controls></video>

            </td>
          </tr>
          <tr  class="aa">
            <td>
                <video src="Video/5 Lionel Messi ● Top 10 Free Kicks That Weren't Goals  !! __HD___HIGH.mp4" poster="AngeloPiza.png" controls></video>

            </td>
          </tr>
          <tr class="aa">
            <td>
                <video aria-placeholder="asdfgh" src="Video/4 Lionel Messi - Wonder Goal vs Real Betis 1.mp4" poster="AngeloPiza.png" controls ></video>

            </td>
          </tr>    

       </div>
    </div>
   
   
<div class="dark">
    <div class="container animate-box" id="fh5co-footer">
        <div class="row">
            <div class="col-sm-4">
                <div><a class="nsavbar-brand" href="#">L-LOCATION <span class="navbar-brand2">VOITURE</span></a></div>
                <br>
                <div class="text-white">Get amazing results working with the best programmers, designers, writers and
                    other top online pros. You can hire us with confidence. Get amazing results working with the best
                    programmers
                </div>
            </div>
            <div class="col-sm-4">
                <div class="icons">VISUALISER VOS PAGES</h3></div>
                <br>
                <table width="100%">
                    <tr>
                        <td><a class="text-white" href="#!">Home</a></td>
                        <td><a class="text-white" href="index.php">Acceuil</a></td>
                    </tr>
                    <tr>
                        <td><a class="text-white" href="liste.php">liste voiture</a></td>
                    </tr>
                    <tr>
                        <td><a class="text-white" href="liste.php">Location</a></td>
                    </tr>
                    <tr>
                        <td><a class="text-white" href="loisir.php">Loisir</a></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="darker">
    <div class="container" id="fh5co-legal">
        <div class="row">
            <div class="col-sm-8 text-white mtext-center">
                &copy; 2021 <a class="text-gr" href="#">L-LOCATION <span class="navbar-brand2">VOITURE</span></a>.
                </div>
        </div>
    </div>
</div>



<script src="./js/jquery.min.js"></script>
<script src="./js/bootstrap.min.js"></script>
<script src="./js/fontawesome.js"></script>
<script src="./js/jquery.waypoints.min.js"></script>
<script src="./js/animate.js"></script>

</body>
</html>

<style>
    video{
        width: 30%;
       margin-left: 40px;
       border: 2px solid orange;
       border-radius: 5px; 
    }
</style>