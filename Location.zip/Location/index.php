<?php
    include './db.php';
?>

<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
    <title>LOCATION</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/animate.css" />
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet">
    <script src="./js/modernizr-3.5.0.min.js"></script>
</head>
<body>

<div class="row top-bar">
    <div class="col-sm-1"></div>
    <div class="col-sm-5 d-sm-block d-none" style="font-size: 13px">
        <i class="fa fa-phone"></i> CAR RENTAL &nbsp;
    </div>
    <div class="col-sm-2 col-6 text-center">
        <i class="fa fa-facebook-square"></i>
        <i class="fa fa-twitter-square"></i>
        <i class="fa fa-instagram"></i>
        <i class="fa fa-google-plus-square"></i>
        <i class="fa fa-linkedin"></i>
    </div>
</div>

<nav class="navbar navbar-expand-lg nav-bar navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="#">L-LOCATION <span class="navbar-brand2"> VOITURE</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto navi">
                <li class="nav-item">
                    <a class="nav-link nav-btn active" href="#">Acceuil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="liste.php">Liste Voiture</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="liste.php">Location</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="loisir.php">Loisir</a>
                </li>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="chat/index.php">Chat</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="recherche.php">Recherche</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div>
    <img class="banner d-none d-sm-block" src="img/v4.jpg">
    <div class="banner-text d-none d-sm-block animate-box" data-animate-effect="fadeInLeft">
        <h2>Chez L-Location  <br> nous vous aidons a  vivre un sejour de reve </h2>
        <div style="width: 45%">avec votre voiture de reve, pour un prix abordable <br>
            Powered by Alberting.com<br><br>
            <a href="liste.php" class="btn btn-banner">VERIFIE LES VOITURES</a>
        </div>
    </div>

</div>

<form method="post" action="recherche.php">
    <div>
        <div class="row aft-banner">
            <div class="col-sm-1"></div>
            <div class="col-sm-2 d-none d-sm-block">
                <div class="g-box">Recherche<br><b>Votre voiture</b></div>
            </div>
            <div class="col-sm-4">
                <div class="text-center orange">Nous sommes la | pour vous servir</div>
            </div>
            <div class="col-sm-4">
                <div class="input-group">
                    <input type="text" class="form-control dark-bg" name="recherche" placeholder="Marque">
                    <div class="input-group-append">
                        <button class="btn btn-outline-secondary btn-org" name="btnR" type="button">Recherche</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>


<form action="liste.php" method="post">
    <div class="smoke">
        <div class="container" id="fh5co-pricing">
            <div class="heading animate-box"><h2><b>CHOISIR VOTRE PLAN</b></h2></div>
            <div class="text-center animate-box"><h3>DE LOCATION</h3></div>
            <br><br>
            <div class="row">
                <div class="col-sm-4 animate-box" data-animate-effect="fadeInLeft">
                    <div class="price-box">
                        <h3><b>BASIC PLAN</b></h3>
                        <h2 class="text-org"><b>$150.99</b></h2>
                        <h3><b>PAR JOURS</b></h3>
                        <div class="gr-line"></div>
                        <div>100% GARANTIE</div>
                        <div class="gr-line"></div>
                        <div>FREE GARAGE</div>
                        <div class="gr-line"></div>
                        <div>1/2 TANK</div>
                        <br>
                        <button class="btn btn-banner">RESERVER</button>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="price-box-dark animate-box">
                        <h3><b> LUXE PLAN</b></h3>
                        <h2 class="text-gr"><b>$500</b></h2>
                        <h3><b>PAR SEMAINE</b></h3>
                        <div class="gr-line"></div>
                        <div>100% GARANTIE</div>
                        <div class="gr-line"></div>
                        <div>FREE GARAGE</div>
                        <div class="gr-line"></div>
                        <div>FULL TANK</div>
                        <br>
                        <button class="btn btn-banner">RESERVER</button>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="price-box animate-box" data-animate-effect="fadeInRight">
                        <h3><b>SPORT</b></h3>
                        <h2 class="text-org"><b>$200.99</b></h2>
                        <h3><b>PAR SEMAINE</b></h3>
                        <div class="gr-line"></div>
                        <div>100% GARANTIE</div>
                        <div class="gr-line"></div>
                        <div>FREE GARAGE</div>
                        <div class="gr-line"></div>
                        <div>FULL TANK</div>
                        <br>
                        <button class="btn btn-banner">RESERVER</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>




<div class="dark">
    <div class="container animate-box" id="fh5co-footer">
        <div class="row">
            <div class="col-sm-4">
                <div><a class="nsavbar-brand" href="#">AL-LOCATION <span class="navbar-brand2">VOITURE</span></a></div>
                <br>
                <div class="text-white">Chez Al-Location nous vous aidons a  vivre un sejour de reve avec votre voiture de reve, pour un prix abordable
                </div>
            </div>
            <div class="col-sm-4">
                <div class="icons">VISUALISER VOS PAGES</h3></div>
                <br>
                <table width="100%">
                    <tr>
                        <td><a class="text-white" href="#!">Home</a></td>
                        <td><a class="text-white" href="index.php">Acceuil</a></td>
                    </tr>
                    <tr>
                        <td><a class="text-white" href="liste.php">liste voiture</a></td>
                    </tr>
                    <tr>
                        <td><a class="text-white" href="liste.php">Location</a></td>
                    </tr>
                    <tr>
                        <td><a class="text-white" href="loisir.php">Loisir</a></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="darker">
    <div class="container" id="fh5co-legal">
        <div class="row">
            <div class="col-sm-8 text-white mtext-center">
                &copy; 2021 <a class="text-gr" href="#">L-LOCATION <span class="navbar-brand2">VOITURE</span></a>.
                </div>
        </div>
    </div>
</div>



<script src="./js/jquery.min.js"></script>
<script src="./js/bootstrap.min.js"></script>
<script src="./js/fontawesome.js"></script>
<script src="./js/jquery.waypoints.min.js"></script>
<script src="./js/animate.js"></script>

</body>
</html>
