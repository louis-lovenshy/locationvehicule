<?php
include("conn.php");

$last_name=mysqli_real_escape_string($conn,$_POST['last_name']);
$first_name=mysqli_real_escape_string($conn,$_POST['first_name']);
$username=mysqli_real_escape_string($conn,$_POST['username']);
$password=mysqli_real_escape_string($conn,$_POST['password']);
$email=mysqli_real_escape_string($conn,$_POST['email']);
$phone=mysqli_real_escape_string($conn,$_POST['phone']);

if($username == "" || $password == ""){
echo "<script>window.alert('Username and Password are required fields!')</script>";
}
else{
$insert_query=mysqli_query($conn,"INSERT INTO users VALUES(null, '$username', '$last_name', '$first_name', '$password','$email','$phone')")or die(mysqli_error($conn));
echo "<script>window.alert('Account successfully created! You can now login with your credentials.')</script>";
echo "<script>window.location.href='index.php?registered'</script>";
}

?>