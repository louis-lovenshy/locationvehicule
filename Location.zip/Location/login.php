<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="log.css">
	<title>LOGIN</title>
</head>
<body>
	<?php
		if (isset($_GET['login'])) 
		{
			$login = $_GET['login'];

			if ($login == 0) 
			{ ?>
				<script type="text/javascript">
					alert("Nom d'utilisateur ou mot de passe invalide !");
				</script>

			<?php }
		}
	?>
	<div class="login-box">
		<h2>Login</h2>
		<form method="POST">
			<br><br>
			<div class="user-box">
				<input type="text" name="username" required="">
				<label>Username</label>
			</div><br><br>
			
			<div class="user-box">
				<input type="password" name="password" required="">
				<label>Password</label>
			</div><br><br>

		  <a>
			<button
				  type="submit" class="btn"> 
						<span></span>
						<span></span>
						<span></span>
						<span></span>
	                  Connect
                    </button>
					</a>
			<br>
			<div>
				<a href="signin.php">Creer un compte ?</a>
			</div>
		</form>
	</div>

	

	<?php 
		include './db.php';
		session_start();

		if (isset($_POST['username']) and isset ($_POST['password'])) 
		{
			$username = mysqli_real_escape_string($db,htmlspecialchars($_POST['username']));
			$password = mysqli_real_escape_string($db,htmlspecialchars($_POST['password']));

			$requete = "SELECT count(*) FROM clients where username = '".$username."' AND password = '".$password."' ";
	        $exec_requete = mysqli_query($db,$requete);
	        $reponse      = mysqli_fetch_array($exec_requete); 
	        $count = $reponse['count(*)'];

	        if ($count == 1)
	        {
	        	$_SESSION['username'] = $username;
				header("Location: liste.php");
			}

			else
			{
				header("Location: login.php?login=0");
			}
		}
	?>
</body>
</html>