<?php
 include './db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>VOITURE</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/animate.css" />
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet">
    <script src="./js/modernizr-3.5.0.min.js"></script>
</head>
<body>
<div class="row top-bar">
    <div class="col-sm-1"></div>
    <div class="col-sm-5 d-sm-block d-none" style="font-size: 13px">
        <i class="fa fa-comments"></i> CAR RENTAL &nbsp;
    </div>
    <div class="col-sm-2 col-6 text-center">
        <i class="fa fa-facebook-square"></i>
        <i class="fa fa-twitter-square"></i>
        <i class="fa fa-instagram"></i>
        <i class="fa fa-google-plus-square"></i>
        <i class="fa fa-linkedin"></i>
    </div>
    <div class="col-sm-3 col-6 login">
        <a href="#!" class="text-white">Login</a> &nbsp; 
        <a href="#!" class="text-white">Sign Up</a>&nbsp;
    </div>
</div>

<nav class="navbar navbar-expand-lg nav-bar navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="#">L-LOCATION <span class="navbar-brand2"> VOITURE</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto navi">
                <li class="nav-item">
                    <a class="nav-link nav-btn active" href="index.php">Acceuil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="liste.php">Liste Voiture</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="#">Location</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link nav-btn" href="chat/index.php">Chat</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link nav-btn" href="loisir.php">Loisir</a>
                </li>
                <li class="nav-item">
            </ul>
        </div>
    </div>
   
</nav>
<div class="right"> 
        <br>
        <marquee behavior="" direction="">Hello ! Welcome to <b> Page Recherche</b> </marquee>
      </div>
    

    
       <?php
            


            if ( isset($_POST['recherche']) )
               $recherche = htmlentities($_POST['recherche']);

    
    
            if (!empty($recherche))
            { 
                $sql = "SELECT * FROM vehicules WHERE marque LIKE '%$recherche%'"; 
                $result = mysqli_query($db, $sql);                         
    
                   $nb = mysqli_num_rows($result)  ;           
    
            if($nb!= 0) 
            {
                echo '<br>'; 
                echo '<br>'; 
               echo '<center>';   
               echo '
                   <form action="" method="Post">
                   <input type="text" name="recherche" size="50px">
                   <input  class="btn btn-outline-secondary btn-org" type="submit" value="Recherche">
                   </form>';
              echo '</center>';
              echo '<font color="grern">Résultat de votre recherche dans la base L-LOCATION </font><br/>
                    <font size="5px">'.$nb.'</font>';
    
    
            if($nb> 1)
            {
                echo ' <font size="5px" color="red">Résultats</font> ';
            }
            else
            {
                    echo ' <font size="5px" color="blue">Résultat trouvé</font>  ';
            } 
    
               echo  '<font size="5px">dans la base de données L-LOCATION :</font><br/><br/>';
                
    
    
    
            while($donnees = mysqli_fetch_array($result))
            {
            ?>
    
                  <img src="img
                     /<?php echo ($donnees['image']);  ?>.png"/>
                     <br>
                     <br>
            <?php
                  echo '<span>';   
                  echo '<font size="5px">'.'MARQUE  : '.$donnees['marque'].'</font><br/>';
                  echo  '<font size="5px">'.'MODELE  : '.$donnees['modele'].'</font><br/>';
                  echo  '<font size="5px">'.'TRANSMISSION  : '.$donnees['transmission'].'</font><br/>';
                  echo '<font size="5px">'.'prix  : $ '.$donnees['prix'].'</font><br/><br/><br/>';
                  echo '</span>';
            ?>
    
            <?php
            } // fin de la boucle
            ?>
    
    
            <?php
            }
    
    
            else {
                echo '<center>'; 
                echo '<br>';  
                echo '<br>';  
                echo '
                   <form action="" method="Post">
                   <input type="text" name="recherche" size="50px">
                   <input type="submit"  class="btn btn-outline-secondary btn-org" value="Recherche">
                   </form>';
                echo '</center>';
                echo '<h5>Pas de résultats</h3>';
                echo '<pre>Cette voiture n est pas disponible dans notre base de donnes, veillez entrer une autree voiture
                      <font color="blue">' .$_POST['recherche'].'</font></pre>';
              
             }
            }
    
            else
            { 
    
    
             echo '<center>';   
             echo '<br>';  
             echo '<br>';  

             echo '
                   <form action="" method="Post">
                   <input type="text" name="recherche" size="60px">
                   <input type="submit" class="btn btn-outline-secondary btn-org"  value="Recherche">
                   </form>';
             echo '</center>';     
            }
        
        ?>
         
</body>
</html>