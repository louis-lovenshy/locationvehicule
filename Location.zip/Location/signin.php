<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<?php
		if (isset($_GET['login'])) 
		{
			$login = $_GET['login'];

			if ($login == 0) 
			{ ?>
				<script type="text/javascript">
					alert("Valeur invalide !");
				</script>

			<?php }
		}
	?>
	<div>
		<h1>Inscription</h1>	
	</div>

	<form method="POST">
		<div>
			<label>Nom : </label>
			<input type="text" name="nom" required="">
		</div><br><br>
		
		<div>
			<label>Prenom : </label>
			<input type="text" name="prenom" required="">
		</div><br><br>

		<div>
			<label>Nom d'utilisateur : </label>
			<input type="text" name="username" required="">
		</div><br><br>

		<div>
			<label>Mot de passe : </label>
			<input type="password" name="password" required="">
		</div><br><br>

		<div>
			<input type="submit" name="submit">
		</div><br><br>
	</form>

	<?php 
		include './db.php';

		if (isset($_POST['nom']) and isset($_POST['prenom']) and isset($_POST['username']) and isset ($_POST['password'])) 
		{
			$nom = mysqli_real_escape_string($db,htmlspecialchars($_POST['nom']));
			$prenom = mysqli_real_escape_string($db,htmlspecialchars($_POST['prenom']));
			$username = mysqli_real_escape_string($db,htmlspecialchars($_POST['username']));
			$password = mysqli_real_escape_string($db,htmlspecialchars($_POST['password']));
			

			$requete = "INSERT INTO clients VALUES (null, '$nom', '$prenom', '$username', '$password') ";
	        $exec_requete = mysqli_query($db,$requete);
	        $reponse      = mysqli_fetch_array($exec_requete); 
	        $count = $reponse['count(*)'];

	        if ($count == 1)
	        {
	        	$_SESSION['username'] = $username;
				header("Location: ..\setReservation.php");
			}

			else
			{
				header("Location: .\login.php?login=0");
			}
		}
	?>
</body>
</html>